CREATE TABLE anuncio (
cod_anuncio int NOT NULL AUTO_INCREMENT PRIMARY KEY,
imagem varchar(5000) NULL,
dt_publicacao date NULL,
descricao_anuncio varchar(300) NULL,
categoria varchar(80) NULL,
titulo varchar(80) NULL,
pagamento int NULL
);

CREATE TABLE local (
estado varchar(80) NULL,
cep int NOT NULL PRIMARY KEY,
cidade varchar(80) NULL
);

CREATE TABLE user_contrata (
cpf_user_contrata int NOT NULL PRIMARY KEY,
cod_user int NOT NULL,
cod_anuncio int NOT NULL,
FOREIGN KEY(cod_anuncio) REFERENCES anuncio (cod_anuncio)
);

CREATE TABLE lance (
cpf_user_contratado int NOT NULL,
cod_anuncio int NOT NULL,
data_hora timestamp NULL,
valor int NULL,
confirmado tinyint NOT NULL,
FOREIGN KEY(cod_anuncio) REFERENCES anuncio (cod_anuncio)
);

CREATE TABLE user_contratado (
cpf_user_contratado int NOT NULL PRIMARY KEY,
cod_user int NOT NULL
);

CREATE TABLE relacao (
cod_user int NOT NULL,
id_user int NOT NULL
);

CREATE TABLE user (
cod_user int NOT NULL AUTO_INCREMENT PRIMARY KEY,
nome varchar(80) NULL,
sobrenome varchar(80) NULL,
email varchar(80) NULL,
pwo varchar(30) NULL,
tel varchar(20) NULL,
sexo varchar(20) NULL,
cidade_user varchar(80) NULL,
estado_user varchar(80) NULL,
desc_user varchar(5000) NULL,
areas_user varchar(5000) NULL,
formacao varchar (5000) NULL
);


CREATE TABLE tipo_user (
id_user int NOT NULL AUTO_INCREMENT PRIMARY KEY
);

ALTER TABLE user_contrata ADD FOREIGN KEY(cod_user) REFERENCES user (cod_user);
ALTER TABLE lance ADD FOREIGN KEY(cpf_user_contratado) REFERENCES user_contratado (cpf_user_contratado);
ALTER TABLE user_contratado ADD FOREIGN KEY(cod_user) REFERENCES user (cod_user);
ALTER TABLE relacao ADD FOREIGN KEY(cod_user) REFERENCES user (cod_user);
ALTER TABLE relacao ADD FOREIGN KEY(id_user) REFERENCES tipo_user (id_user);
