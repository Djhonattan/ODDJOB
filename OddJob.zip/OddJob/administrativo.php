<?php
session_start();
if(!empty($_SESSION['cod_user'])){
	echo "Olá ".$_SESSION['nome']." ".$_SESSION['sobrenome'].", Bem vindo <br> Senha: ".$_SESSION['pwo']."<br> COD: ".$_SESSION["cod_user"]. "<br> Tel: ".$_SESSION["tel"]. "<br>";
	echo "<a href='sair.php'>Sair</a>";
}
