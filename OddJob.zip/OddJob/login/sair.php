<?php

session_start();
unset($_SESSION['cod_user'], $_SESSION['email'], $_SESSION['pwo']);

$_SESSION['msg'] = "Deslogado com sucesso";
header("Location: loginReal.php");