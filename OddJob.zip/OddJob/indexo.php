<?php
session_start();
include("home.php");
$situacao=$_GET['situacao'];
?>

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

</head>

<body>


<</div>

            </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="pop1" role="tabpanel" aria-labelledby="pop1-tab">
                    <div class="pt-4"></div>
                    <div class="container">
                        <div class="row">
                            <div class="text-center">
                                <div class="card-group">
                                    <?php
                                    for ($i = 1; $i <= $_SESSION['UltCod']; $i++) {

                                        $result_UltCod = "SELECT cod_anuncio FROM anuncio ORDER BY cod_anuncio DESC LIMIT 1;";

                                        $_SESSION['UltCod'] = $result_UltCod;

                                            $result_titulo = "SELECT titulo FROM anuncio WHERE cod_anuncio = '$i';";
                                            $result_imagem = "SELECT imagem FROM anuncio WHERE cod_anuncio = '$i';";

                                            $_SESSION['titulo_A'] =  $result_titulo;
                                            $_SESSION['imagem_A'] =  $result_imagem;


                                    echo '<div class="card">
                                        <img class="card-img-top" src="'; echo $_SESSION['imagem_A']; echo'" alt="Card image cap">
                                        <div class="card-body">
                                            <h4 class="card-title">'; echo $_SESSION['titulo_A']; echo '</h4>
                                            <p class="card-text">Lance Médio em R$30</p>
                                        </div>
                                        <div class="card-footer">
                                            <button type="button" class="btn btn-danger btn-block">Saiba Mais</button>
                                        </div>
                                    </div>';
                                    }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


                <section class="py-5">
                    <div class="container">
                        <div class="row mb-3">
                            <div class="col-md-12">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-center ">


</body>
</html>
