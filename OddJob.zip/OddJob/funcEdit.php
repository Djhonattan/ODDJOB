<?php
session_start();
include("valida.php");

function inp_nome($a){
    echo $a;
}

function inp_sobrenome($a){
    echo $a;
}

function inp_cidade($a){
    echo $a;
}

function inp_estado($a){
    echo $a;
}

function inp_tel($a){
    echo $a;
}

function inp_email($a){
    echo $a;
}

function inp_pwo($a){
    echo $a;
}

function inp_formacao($a){
    echo $a;
}

function inp_areas($a){
    echo $a;
}

function inp_desc($a){
    echo $a;
}
    $multiA = explode(",", $_SESSION['areas_user']);



/*$chamaNome = inp_nome($_SESSION['nome']);
$chamaSobrenome = inp_sobrenome($_SESSION['sobrenome']);
$chamaCidade = inp_cidade($_SESSION['cidade']);
$chamaEstado = inp_estado($_SESSION['estado']);
$chamaTel = inp_tel($_SESSION['tel']);
$chamaEmail = inp_email($_SESSION['email']);
$chamaPwo = inp_pwo($_SESSION['pwo']);
$chamaFormacao = inp_formacao($_SESSION['formacao']);
$chamaAreas = inp_areas($_SESSION['areas_user']);
$chamaAreas = inp_desc($_SESSION['desc_user']);
*/