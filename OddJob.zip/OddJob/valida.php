<?php
session_start();
include_once("conexao.php");
$btnLogin = filter_input(INPUT_POST, 'btnLogin', FILTER_SANITIZE_STRING);
if($btnLogin) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
    $pwo = filter_input(INPUT_POST, 'pwo', FILTER_SANITIZE_STRING);
    //echo "$email - $pwo";
}
	if((!empty($email)) AND (!empty($pwo))) {
        //echo password_hash($pwo, PASSWORD_DEFAULT);
        //Pesquisar o usuário no BD
        $result_email = "SELECT cod_user, nome, sobrenome, email, pwo, tel, sexo, cidade_user, estado_user, formacao, desc_user, areas_user FROM user WHERE email = '$email' LIMIT 1;";
        $resultado_email = mysqli_query($conn, $result_email);
            $row_email = mysqli_fetch_assoc($resultado_email);

            if ($pwo == $row_email['pwo']) {
                $_SESSION['cod_user'] = $row_email['cod_user'];
                $_SESSION['nome'] = $row_email['nome'];
                $_SESSION['sobrenome'] = $row_email['sobrenome'];
                $_SESSION['email'] = $row_email['email'];
                $_SESSION['tel'] = $row_email['tel'];
                $_SESSION['sexo'] = $row_email['sexo'];
                $_SESSION['pwo'] = $row_email['pwo'];
                $_SESSION['cidade'] = $row_email['cidade_user'];
                $_SESSION['estado'] = $row_email['estado_user'];
                $_SESSION['formacao'] = $row_email['formacao'];
                $_SESSION['desc_user'] = $row_email['desc_user'];
                $_SESSION['areas_user'] = $row_email['areas_user'];
                $_SESSION['logado'] = true;

        $result_anuncio = "SELECT cod_anuncio, titulo, imagem, dt_publicacao, descricao_anuncio, categoria, pagamento FROM anuncio;";
        $resultado_anuncio = mysqli_query($conn, $result_anuncio);
            $row_anuncio = mysqli_fetch_assoc($resultado_anuncio);

            $_SESSION['cod_anuncio'] = $row_anuncio['cod_anuncio'];
            $_SESSION['titulo'] = $row_anuncio['titulo'];
            $_SESSION['imagem'] = $row_anuncio['imagem'];
            $_SESSION['dt_publicacao'] = $row_anuncio['dt_publicacao'];
            $_SESSION['descricao_anuncio'] = $row_anuncio['descricao_anuncio'];
            $_SESSION['categoria'] = $row_anuncio['categoria'];
            $_SESSION['pagamento'] = $row_anuncio['pagamento'];


                header("Location: conta.php");
            }else {
                $_SESSION['msg'] = "Login ou senha incorreto!";
                header("Location: loginReal.php");
            }
    }