<?php

//$CIDR = "/31";

function numHosts ($a){
    switch ($a) {
    case "/24":
        $octMask[3] = 0;
    	$IPs = 256 - $octMask[3];
        break;

    case "/25":
        $octMask[3] = 128;
        $IPs = 256 - $octMask[3];
        break;

    case "/26":
        $octMask[3] = 192;
		$IPs = 256 - $octMask[3];
        break;

    case "/27":
        $octMask[3] = 224;
		$IPs = 256 - $octMask[3];
        break;

    case "28":
        $octMask[3] = 240;
		$IPs = 256 - $octMask[3];
        break;

    case "/29":
        $octMask[3] = 248;
		$IPs = 256 - $octMask[3];
        break;

    case "/30":
        $octMask[3] = 252;
		$IPs = 256 - $octMask[3];
        break;

    case "/31":
        $octMask[3] = 254;
		$IPs = 256 - $octMask[3];
        break;

    case "/32":
        $octMask[3] = 255;
        $IPs = 256 - $octMask[3];
        break;
    }

    if (($a == "/31" or $a == "/32")){
        $numHosts = 0;
        echo $numHosts;
    }else {
        $numHosts = $IPs - 2;
        echo $numHosts;
    }
}
//$chamaNumHots = numHosts($octMask[3], $CIDR);
//echo $chamaNumHots;