<?php
//$ip = '192.168.0.255';

function priVal ($a, $b){
	$octetos = explode (".", $b);
	switch ($a) {
    case "/24":
    	$octetos[3] = 0;
        break;

    case "/25":
        $octetos[3] = 0;
        break;

    case "/26":
        $octetos[3] = 0;
        break;

    case "/27":
        $octetos[3] = 0;
        break;

    case "/28":
        $octetos[3] = 0;
        break;

    case "/29":
		$octetos[3] = 0;
        break;

    case "/30":
		$octetos[3] = 0;
        break;

    case "/31":
        $octetos[3] = 0;
        break;

    case "/32":
        $octetos[3] = 0;
        break;
    }



$PV = $octetos[3] + 1;

echo($octetos[0]. "." . $octetos[1]. "." . $octetos[2]. "." .$PV);
}