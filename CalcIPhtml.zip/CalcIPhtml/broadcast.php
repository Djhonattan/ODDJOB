<?php
//$CIDR = "/31";

function broadcast ($a,$b){
$octetos = explode (".", $b);

switch ($a) {
    case "/24":
        $octetos[3] = 0;
        $broadcast = 1+2+4+8+16+32+64+128;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/25":
        $octetos[3] = 128;
        $broadcast = 1+2+4+8+16+32+64;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/26":
        $octetos[3] = 192;
        $broadcast= 1+2+4+8+16+32;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/27":
        $octetos[3] = 224;
        $broadcast= 1+2+4+8+16;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/28":
        $octetos[3] = 240;
        $broadcast= 1+2+4+8;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/29":
        $octetos[3] = 248;
        $broadcast= 1+2+4;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/30":
        $octetos[3] = 252;
        $broadcast= 1+2;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/31":
        $octetos[3] = 254;
        $broadcast= 1;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;

    case "/32":
        $octetos[3] = 255;
        $broadcast= 1;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $broadcast;
        break;
    }
}
