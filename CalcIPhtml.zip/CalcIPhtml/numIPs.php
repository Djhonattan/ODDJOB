<?php

//$CIDR = "/24";

function IPs ($a){
    
    switch ($a) {
    case "/24":
        $octMask[3] = 0;
    	$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/25":
        $octMask[3] = 128;
        $IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/26":
        $octMask[3] = 192;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/27":
        $octMask[3] = 224;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "28":
        $octMask[3] = 240;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/29":
        $octMask[3] = 248;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/30":
        $octMask[3] = 252;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/31":
        $octMask[3] = 254;
		$IPs = 256 - $octMask[3];
        echo $IPs;
        break;

    case "/32":
        $octMask[3] = 255;
        $IPs = 256 - $octMask[3];
        echo $IPs;
        break;
    }
}

//$chamaIPs = IPs($octMask[3]);
//echo $chamaIPs;