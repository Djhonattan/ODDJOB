<?php
$CIDR = "/24";
$ip = "192.168.0.1";
function endRedes ($a,$b){

	$mascara = "255.255.255.255";
    $octMask = explode (".", $mascara);

switch ($a) {
    case "/24":
        $octMask[3] = 0;
        break;

    case "/25":
        $octMask[3] = 128;
        break;

    case "/26":
        $octMask[3] = 192;
        break;

    case "/27":
        $octMask[3] = 224;
        break;

    case "28":
        $octMask[3] = 240;
        break;

    case "/29":
        $octMask[3] = 248;
        break;

    case "/30":
        $octMask[3] = 252;
        break;

    case "/31":
        $octMask[3] = 254;
        break;

    case "/32":
        $octMask[3] = 255;
        break;
    }

	$octetos = explode('.',$b);
	$IPs = 256 - $octMask[3];
	$qtdSR = 256 / $IPs;

	$endRedes = 0;
	$QR = 0;

	for($i = 0; $i <= $qtdSR; $i++)
	{	
		$QR= $QR + 1;
		$endRedes = $endRedes + $IPs;	
		$broadcast = $endRedes + ($endRedes - 1);
		$PV = $endRedes + 1;
		$UV = $broadcast - 1;
	echo ("<br>Numeração da Rede: " . $QR . "<br>Rede: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $endRedes . "<br>PV: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $PV . " <br>UV: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $UV . "<br> broadcast: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $broadcast . "<br>");
	}
}
$chamaEndRedes = endRedes($CIDR,$ip);
//echo ("PV: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $PV . " <br>UV: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $UV . "<br> broadcast: " . $octetos[0] . "." . $octetos[1] . "." . $octetos[2] . "." . $broadcast);
//echo $octetos[0] . $octetos[1] . $octetos[2] . $octetos[3]