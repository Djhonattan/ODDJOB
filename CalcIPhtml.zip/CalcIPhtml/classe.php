<?php
//$CIDR = "/31";

function classe ($a){
$octetos = explode (".", $a);

	if(($octetos[0] >= 1 and $octetos[0] <= 126)){
		echo "Classe A";
	}elseif(($octetos[0] >= 128 and $octetos[0] <= 191)){
		echo "Classe B";
	}elseif(($octetos[0] >= 192 and $octetos[0] <= 223)){
		echo "Classe C";
	}elseif(($octetos[0] >= 224 and $octetos[0] <= 239)){
		echo "Classe D";
	}elseif(($octetos[0] >= 240 and $octetos[0] <= 255)){
		echo "Classe E";
	}
}