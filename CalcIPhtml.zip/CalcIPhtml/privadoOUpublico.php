<?php
//$CIDR = "/31";
//$ip = "172.15.0.1";


	function privPub($a){
	
	$octetos = explode (".", $a);

	if (($octetos[0] == 192 and $octetos[1] == 168)  or ($octetos[0] == 10) or ($octetos[0] == 172 and $octetos[1] >= 16 and $octetos[1] <= 31)){
    	echo " privada";
	}else{
    	echo " publica";
	}
}