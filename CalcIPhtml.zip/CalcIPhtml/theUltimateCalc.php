<?php
include('cabecalho.php');
include('broadcast.php');
include('classe.php');
include('maskSR.php');
include('numHosts.php');
include('numIPs.php');
include('primeiroValido.php');
include('qtdSR.php');
include('rede.php');
include('ultimoValido.php');
include('privadoOUpublico.php');

    $ip = $_POST['ip'];
    $CIDR = $_POST['CIDR'];
	//$ip = "192.168.0.2";
	//$CIDR = "/24";

/*$chamaBroadcast = broadcast($CIDR,$ip);
$chamaRede = rede($CIDR,$ip);
$chamaMaskSR = maskSR($CIDR);
$chamaClasse = classe($ip);
$chamaUltVal = ultVal($ip);
$chamaPriVal = priVal($ip);
$chamaNumIps = IPs($CIDR);
$chamaNumHosts = numHosts($CIDR);
$chamaQtdSR = qtdSR($CIDR);
$chamaPrivouPub = privPub($ip);
*/
//echo $chamaBroadcast;
?>

<table class="ui very basic table" style="padding: 5%;">
  <thead>
    <tr>
      <th>info</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>IP</td>
      <td><?php echo $ip;?></td>
    </tr>
   <tr>
      <td>Mascara</td>
      <td><?php echo $chamaMaskSR = maskSR($CIDR);?></td>
    </tr>
    <tr>
      <td>Rede</td>
      <td><?php $chamaRede = rede($CIDR,$ip)?></td>
    </tr>
    <tr>
      <td>Primeiro IP Valido</td>
      <td><?php $chamaPriVal = priVal($CIDR,$ip);?></td>
    </tr>
    <tr>
      <td>Ultimo IP Valido</td>
      <td><?php $chamaUltVal = ultVal($ip, $CIDR);?></td>
    </tr>
    <tr>
      <td>Broadcast</td>
      <td><?php echo $chamaBroadcast = broadcast($CIDR,$ip);?></td>
    </tr>
    <tr>
      <td>Hosts</td>
      <td><?php $chamaNumHosts = numHosts($CIDR);?></td>
    </tr>
    <tr>
      <td>IPs</td>
      <td><?php $chamaNumIps = IPs($CIDR);?></td>
    </tr>
    <tr>
      <td>Quantidade de Sub Redes</td>
      <td><?php $chamaQtdSR = qtdSR($CIDR);?></td>
    </tr>
    <tr>
      <td>Classe</td>
      <td><?php echo $chamaClasse = classe($ip)?></td>
    </tr>
    <tr>
      <td>Dominio</td>
      <td><?php $chamaPrivouPub = privPub($ip)?></td>
    </tr>

  </tbody>
</table>
	
	</body>
</html>

