<!DOCTYPE html>
<html>
<head>
	<title> Calculadora IP </title>
	 <link rel="stylesheet" type="text/css" href="estilo.css">
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">  
		<div class="fundo">
			<cneter><img id="logo" src="logo_calculadora.png"></center>
		</div>
	</nav>
</head>
<body>

<?php include('theUltimateCalc.php');?>

<table class="ui very basic table" style="padding: 5%;">
  <thead>
    <tr>
      <th>info</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>IP</td>
      <td><?php echo $ip;?></td>
    </tr>
   <tr>
      <td>Mascara</td>
      <td><?php echo $chamaMaskSR;?></td>
    </tr>
    <tr>
      <td>Rede</td>
      <td><?php echo $chamaRede;?></td>
    </tr>
    <tr>
      <td>Primeiro IP Valido</td>
      <td><?php echo $chamaPriVal;?></td>
    </tr>
    <tr>
      <td>Ultimo IP Valido</td>
      <td><?php echo $chamaUltVal;?></td>
    </tr>
    <tr>
      <td>Broadcast</td>
      <td><?php echo $chamaBroadcast;?></td>
    </tr>
    <tr>
      <td>Hosts</td>
      <td><?php echo $chamaNumHosts;?></td>
    </tr>
    <tr>
      <td>IPs</td>
      <td><?php echo $chamaNumIps;?></td>
    </tr>
    <tr>
      <td>Quantidade de Sub Redes</td>
      <td><?php echo $chamaQtdSR;?></td>
    </tr>
    <tr>
      <td>Dominio</td>
      <td></td>
    </tr>

  </tbody>
</table>
	
	</body>
</html>
