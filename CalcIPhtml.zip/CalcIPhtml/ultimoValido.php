<?php
//$ip = '192.168.0.255';



function ultVal($a, $b){
	$octetos = explode (".", $a);
	
	switch ($b) {
    case "/24":
        $octetos[3] = 0;
        $broadcast = 1+2+4+8+16+32+64+128-1;
        break;

    case "/25":
        $octetos[3] = 128;
        $broadcast = 2+4+8+16+32+64+128-1;
        break;

    case "/26":
        $octetos[3] = 192;
        $broadcast= 4+8+16+32+64+128-1;
        break;

    case "/27":
        $octetos[3] = 224;
        $broadcast= 8+16+32+64+128-1;
        break;

    case "/28":
        $octetos[3] = 240;
        $broadcast= 16+32+64+128-1;
        break;

    case "/29":
        $octetos[3] = 248;
        $broadcast= 32+64+128-1;
        break;

    case "/30":
        $octetos[3] = 252;
        $broadcast= 64+128-1;
        break;

    case "/31":
        $octetos[3] = 254;
        $broadcast= 128-1;
        break;

    case "/32":
        $octetos[3] = 255;
        $broadcast= 0;
        break;
}

$UV = $broadcast - 1;

echo($octetos[0] . "." . $octetos[1]. "." . $octetos[2]. "." . $UV);
}

