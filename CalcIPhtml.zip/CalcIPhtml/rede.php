<?php
//$CIDR = "/28";

function rede($a,$b){

$octetos = explode (".", $b);

switch ($a) {
    case "/24":
    	$octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/25":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/26":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/27":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/28":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/29":
		$octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/30":
		$octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/31":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;

    case "/32":
        $octetos[3] = 0;
        echo $octetos[0] .".". $octetos[1] .".". $octetos[2] .".". $octetos[3];
        break;
    }
}