<!DOCTYPE html>
<html>
<head>
	<title> Calculadora IP </title>
	 <link rel="stylesheet" type="text/css" href="estilo.css">
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">  
		<div class="fundo">
			<cneter><img id="logo" src="logo_calculadora.png"></center>
		</div>
	</nav>
</head>