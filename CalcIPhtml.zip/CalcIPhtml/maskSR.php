<?php
//$CIDR = "/31";

function maskSR($a){

    $mascara = "255.255.255.255";
    $octMask = explode (".", $mascara);

switch ($a) {
    case "/24":
        $octMask[3] = 0;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/25":
        $octMask[3] = 128;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/26":
        $octMask[3] = 192;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/27":
        $octMask[3] = 224;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "28":
        $octMask[3] = 240;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/29":
        $octMask[3] = 248;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/30":
        $octMask[3] = 252;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/31":
        $octMask[3] = 254;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;

    case "/32":
        $octMask[3] = 255;
        echo $octMask[0] .".". $octMask[1] .".". $octMask[2] .".". $octMask[3];
        break;
    }
}


//$chamaMaskSR = maskSR($CIDR);
//echo $chamaMaskSR;

?>