    <?php
    session_start();
    include("funcEdit.php");
    include("home.php");
    include("valida.php");

    $areas = explode(",", $_SESSION['areas_user']);

    $situacao=$_GET['situacao'];
?>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  <!------ Include the above in your HEAD tag ---------->

  <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

<div class="container" >
    <div class="row">
        <div class="col-md-offset-2 col-md-8 col-lg-offset-3 col-lg-6">
         <div class="well profile" style="margin-left: -350px !important;">
            <div class="col-sm-12">
                <div class="col-xs-12 col-sm-8">


<hr>
<div class="container bootstrap snippet">
    <div class="row">
      <div class="col-sm-3"><!--left col-->


      
<div class="text-center">
 	<label for="first_name"><h2>Editar Anuncio</h2></label>

 </div>

      <div class="text-center">
        <img src="http://belindaallen.com.au/wp-content/themes/shapely/assets/images/placeholder.jpg" class="avatar img-circle img-thumbnail" alt="avatar">
        <h6>Uma foto que se refere ao serviço</h6>
        <input type="file" class="text-center center-block file-upload">
      </div></hr><br>



         

          
        </div><!--/col-3-->
      <div class="col-sm-9">
            <ul class="nav nav-tabs">
              </ul>


          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                  <form class="form" action="editaPerfil.php" method="post" id="registrationForm">
                      <div class="form-group">
                          <div class="separa" style="margin-left: 50px";>
                          <div class="col-xs-6">
                              <label for="first_name"><h4>Título</h4></label>
                              <input type="text" value="<?php echo $_SESSION['nome']; ?>" class="form-control" name="nome">
                          </div>

                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="last_name"><h4>Orçamento</h4></label>
                              <input type="text" value="<?php $chamaSobrenome = inp_sobrenome($_SESSION['sobrenome']); ?>" class="form-control" name="sobrenome">
                          </div>
                      </div>

                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="password"><h4>Nome da Cidade</h4></label>
                              <input type="text" value="<?php $chamaPwo = inp_pwo($_SESSION['pwo']); ?>" class="form-control" name="pwo">
                          </div>
                      </div>
                      
                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Sigla do Estado</h4></label>
            <label></label>
                <select class="form-control" name="estado" style="height: 35px;">
                  <option>AC</option>
                  <option>AL</option>
                  <option>AP</option>
                  <option>AM</option>
                  <option>BA</option>
                  <option>CE</option>
                  <option>DF</option>
                  <option>ES</option>
                  <option>GO</option>
                  <option>MA</option>
                  <option>MT</option>
                  <option>MS</option>
                  <option>MG</option>
                  <option>PA</option>
                  <option>PB</option>
                  <option>PR</option>
                  <option>PE</option>
                  <option>PI</option>
                  <option>RJ</option>
                  <option>RN</option>
                  <option>RS</option>
                  <option>RO</option>
                  <option>RR</option>
                  <option>SC</option>
                  <option>SP</option>
                  <option>SE</option>
                </select>
                          </div>
                      </div>
                   

             
                      <div class="form-group" >
                          <div class="col-xs-6">
                          	<section style="margin-top:">
                            <label for="password2"><h4>Descrição do Serviço</h4></label>
                              <textarea id="desc_user" value="<?php $chamaDesc = inp_desc($_SESSION['desc_user'])?>" class="form-control" cols="30" rows="7"></textarea> 
                            
                          </section>

                          </div>
                          </div>
                         <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Categoria</h4></label>
            <label></label>
                <select class="form-control" name="categoria" style="height: 35px;">
                  <option>Eletricista</option>
                                        <option>Chaveiro</option>
                                        <option>Jardineiro</option>
                                        <option>Pintor</option>
                                        <option>Confeiteiro</option>
                                        <option>Segurança</option>
                                        <option>Dedetizador</option>
                                        <option>Mecânico</option>
                </select>
                          </div>
                      </div>

                           </div>
                      </div>
                           <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Salvar</button>
                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Resetar</button>
                            </div>
                      </div>
              </div><!--/tab-pane-->
          </div><!--/tab-content-->



</body>
</html>