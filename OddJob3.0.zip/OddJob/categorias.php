<?php
    include("home.php");
    $situacao=$_GET['situacao'];
?>
	 <meta charset="UTF-8">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awesome -->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
  
</head>

<body>

<div class="container h-100">
      <div class="d-flex justify-content-center h-100">
        <div class="searchbar">
          <input class="search_input" type="text" name="" placeholder="Estou procurando por...">
          <a href="#" class="search_icon"><i class="fa fa-search"></i></a>
        </div>
      </div>
    </div>

<div class="container">
    <div class="row">
    <ul>
        <a href="lele.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab  item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-bolt fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3>Eletricista</h3>
                            </p>
                        
                </div>
                    
            </div>
        </div>
        </a>
        <a href="chave.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-key fa-5x fa-icon-image" ></i>
                        <p class="item-title">
                            <h3>Chaveiro</h3>
                        </p>
                </div>
            </div>
        </div>
        </a>
        <a href="jaja.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-leaf fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3>Jardineiro</h3>
                        </p>
                </div>
            </div>
        </div>
        </a>
        <a href="pipi.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-paint-brush fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3>Pintor</h3>
                        </p>
                </div>
            </div>
        </div>
        </a>
        <a href="bolo.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-birthday-cake fa-5x fa-icon-image"></i>
                    <p class="item-title">
                        <h3>Confeiteiro</h3>
                    </p>
                </div>
            </div>
        </div>
        </a>
        <a href="guarda.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-shield fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3>Segurança</h3>
                        </p>
                </div>
            </div>
        </div>
        </a>
        <a href="dede.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
                <div class="folded-corner service_tab_1">
                    <div class="text">
                        <i class="fa fa-bug fa-5x fa-icon-image"></i>
                            <p class="item-title">
                                <h3>Dedetizador</h3>
                            </p>
                </div>
            </div>
        </div>
        </a>
        <a href="meca.php">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-wrench fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3>Mecânico</h3>
                        </p>
                </div>
            </div>
        </div>
    </a> 
       </ul>
    </div>
</div>

  

</body>
</html>
