<?php
    include("home.php");
    $situacao=$_GET['situacao'];
?>
	 <meta charset="UTF-8">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awesome -->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
  
</head>

<body>

<div class="container h-100">
      <div class="d-flex justify-content-center h-100">
        <div class="searchbar">
          <input class="search_input" type="text" name="" placeholder="Estou procurando por...">
          <a href="#" class="search_icon"><i class="fa fa-search"></i></a>
        </div>
      </div>
    </div>


<section class="py-5 featured">
    <div class="container">
    <div class="row mb-3">
        <div class="col-md-12" style="color: white">
            <h2>Anuncios Recentes - Pintor</h2>
        </div>
    </div>
    <div class="row">
            <div class="col-md-12 text-center ">
                <nav class="nav-justified ">

                    
                  </div>
                </nav>

<!------ Modal de Anuncio ---------->
<div class="modal fade product_view" id="product_view">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <a href="#" data-dismiss="modal" class="class pull-right"><span class="glyphicon glyphicon-remove"></span></a>
                <h3 class="modal-title">Manutenção de Rede Elétrica</h3>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 product_img">
                        <img src="lele.png" class="img-responsive">
                    </div>
                    <div class="col-md-6 product_content">
                        <h4>Criador: <span>Jorge Cleiton <img src="MP_SECUROGUARD.png" name="aboutme" width="50" class="img-circle imgUser img-responsive" id="fotoperfil" style="float: right; margin-top: -5px;"></span></h4>
                        <label></label>
                        <h5 style="color: black;">Código: <span>671881194</span></h4>
                        <h5 style="color: black;">Local <span>Balneário Barra do Sul/SC</span></h4>
                        <h5 style="color: black;">Publicado em: <span>22/06/2019</span></h4>
                        
                        <p>Deseja-se que seja realizada a manutenção elétrica preventiva anual de uma escola localizada no centro de Balneário Barra do Sul. As instalações da escola não sofreram manutenção elétrica por longos dois anos, há desconfiança de que elas podem não estar adaptadas às normas de segurança hoje vigentes, devendo ser reformadas de modo a atender todas as especificações técnicas atuais.</p>

                        <h3 class="cost">Orçamento Médio: <span>R$</span> 60,00 <small class="pre-cost"><span>R$</span>100,00</small></h3>

                        <label></label>

                        <div class="space-ten"></div>
                        <div class="btn-ground">
                            <button type="button" class="btn btn-primary"><span class=" glyphicon glyphicon-comment"></span> Realizar Serviço</button>
                            <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-share"></span> Compartilhar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!------ Modal de Anuncio - Fim ---------->

                <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="pop1" role="tabpanel" aria-labelledby="pop1-tab">
                      <div class="pt-4"></div>
                      <div class="container">
                            <div class="row">
                                <div class="text-center">
                                    <div class="card-group">
                                  <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                      </div>   
                                      <div class="card">
                                       <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                          <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                        </div>
                                      <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                      </div>
                                      <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                      </div>
                                    </div>
                                </div>
  </div>
                        </div>
                        
                      </div>


<section class="py-5">
    <div class="container">
    <div class="row mb-3">
        <div class="col-md-12">
        </div>
    </div>
    <div class="row">
            <div class="col-md-12 text-center ">
                <nav class="nav-justified ">

                    
                  </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="pop1" role="tabpanel" aria-labelledby="pop1-tab">
                      <div class="pt-4"></div>
                      <div class="container">
                          <div class="row">
                            <div class="text-center">
                                <div class="card-group">
                                    <div class="card">
                                      <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                           </div>
                                         <div class="card-footer">
                                        <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                     </div>
                                   </div>  
                                 <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                  </div>
                                      <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                      </div>
                                      <div class="card">
                                        <img class="card-img-top" src="pipi.png" alt="Card image cap">
                                        <div class="card-body">
                                        <h4 class="card-title">Pintura de Banheiro</h4>
                                          <h5 class="card-text">Orçamento Médio em R$ 110</h5>
                                          <h5 class="card-text">Joinville/SC</h5>
                                        </div>
                                        <div class="card-footer">
                                           <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                      </div>
                                    </div>
                            </div>
  </div>
                        </div>
                        
                      </div>
</section>


<section class="footer py-5 bg-blue text" id="footer">
    <div class="container py-3">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12 ">
                <p class="">Av. Marquês de Olinda, 460 - Costa e Silva - Joinville/SC</p>
                <ul class="list-unstyled">
                    <li>(47) 3425 3475 - (47) 9964 8006</li>
                    <li>oddjob@gmail.com</li>
                    <li>www.oddjob.com.br</li>
                </ul>
            </div>
            <div class="col-md-9 col-sm-6 col-xs-12 ">
                <div class="row">
                    <div class="col-md-3">
                        <h6 class="pb-2">NOSSAS PROPRIEDADES </h6>
                        <ul class="list-unstyled">
                            <a href="Pixels/index.php"><li> Pixel's Golden Age</li></a>
                            <a href="Rock God/rockgod.html"><li> Rock God</li></a>
                            <a href="#"><li> Irineu Cars</li></a>
                            <a href="#"><li> General Store</li></a>
                            <a href="Palace/listaProfessores.php"><li> Oddjob Palace</li></a>
                            
                            
                        </ul>
                       
                    </div>
                    <div class="col-md-3">
                        <h6 class="pb-2">MENU </h6>
                        <ul class="list-unstyled">
                            <a href="index.php"><li> Home</li></a>
                            <a href="chat.php"><li> Chat</li></a>
                            <a href="#"><li> Anuncios</li></a>
                            <a href="conta.php"><li> Minha Conta</li></a>
                            <a href="#"><li> Categorias</li></a>
                            
                            
                        </ul>
                       
                    </div>
                    <div class="col-md-3">
                        <h6 class="pb-2">SOBRE NÓS </h6>
                        <ul class="list-unstyled">
                            <a href="#"><li> História da Oddjob</li></a>
                            <a href="#"><li> Funcionários</li></a>
                            <a href="#"><li> Mapa do Site</li></a>
                            <a href="#"><li> Termos de Uso</li></a>
                            <a href="#"><li> Política de Privacidade</li></a>
                            
                            
                        </ul>
                       
                    </div>
                    <div class="col-md-3">
                        <h6 class="pb-2">REDES SOCIAIS </h6>
                        <small> Receba as atualizações mais recentes do nosso site e entre em contato conosco</small>
                        <div class="social-icons pt-3">
                            <ul class="list-inline list-unstyled">
                                <a href="#"><li class="list-inline-item"><i class="fa fa-facebook-square fa-2x text-primary"></i></li> </a>
                                <a href="#"><li class="list-inline-item"><i class="fa fa-twitter-square fa-2x text-info"></i></li> </a>
                                <a href="#"><li class="list-inline-item"><i class="fa fa-youtube-play fa-2x text-danger"></i></i></li> </a>
                                <a href="#"><li class="list-inline-item"><i class="fa fa-google-plus-square fa-2x text-danger"></i></li> </a>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="gigi">
<section class="bob"> 
    <div class="container">
        <div class="row text-center" style="font-size: 18px">
            <div class="col-md-12">
                <small> © 2019 Oddjob | Sell, Garcia e Teixeira | Versão 2.5 Λ </small></br>
                <small> Instituto Federal Catarinense - Campus Araquari </small>
            </div>
        </div>
    </div>
</section>
</section>


  

</body>
</html>
