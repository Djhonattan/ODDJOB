<?php

session_start();

$codUser = $_SESSION['cod_user'];

include_once("conexao.php");
if($_SESSION['logado'] == true) {
    $result_codUser = "SELECT cod_user, nome, sobrenome, email, pwo, tel, sexo, cidade_user, estado_user, formacao, desc_user, areas_user FROM user WHERE cod_user = $codUser LIMIT 1;";
    $resultado_codUser = mysqli_query($conn, $result_codUser);
    $row_codUser = mysqli_fetch_assoc($resultado_codUser);

    $_SESSION['cod_user'] = $row_codUser['cod_user'];
    $_SESSION['nome'] = $row_codUser['nome'];
    $_SESSION['sobrenome'] = $row_codUser['sobrenome'];
    $_SESSION['email'] = $row_codUser['email'];
    $_SESSION['tel'] = $row_codUser['tel'];
    $_SESSION['sexo'] = $row_codUser['sexo'];
    $_SESSION['pwo'] = $row_codUser['pwo'];
    $_SESSION['cidade'] = $row_codUser['cidade_user'];
    $_SESSION['estado'] = $row_codUser['estado_user'];
    $_SESSION['formacao'] = $row_codUser['formacao'];
    $_SESSION['desc_user'] = $row_codUser['desc_user'];
    $_SESSION['areas_user'] = $row_codUser['areas_user'];
    $_SESSION['logado'] = true;
    header("Location: conta.php");
}

