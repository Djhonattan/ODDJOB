<?php
    session_start();
	include("home.php");
?>
 <link rel="stylesheet" type="text/css" href="home.css">
<center><section class="fuca3">
	<section class="wast">



							<h3 class="tiete">Login</h3>

        <form method="POST" action="valida.php">
									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="email" class="form-control" placeholder="E-mail" name="email" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="password" class="form-control" placeholder="Senha" name="pwo" required>
									</div>
								</div>
								<center> <h6 style="font-size: 15px!important; margin-top: 80px!important;">Não tem uma conta? <a href="formUsuario.php">Cadastre-se!</a></h6></center>
                                <center><input style="font-size: 18px!important; width: 100px!important; margin-top: 20px!important;" type="submit" name="btnLogin" class="btn btn-outline-primary" value="Login"></center>
        </form>

        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
    </section>