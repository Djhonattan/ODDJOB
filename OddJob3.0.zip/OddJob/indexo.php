 <?php
session_start();
include("home.php");
include_once("conexao.php");
$situacao=$_GET['situacao'];
?>

 <meta charset="UTF-8">
 <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
 <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <!------ Include the above in your HEAD tag ---------->

 <!DOCTYPE html>
 <html>

 <head>
     <meta charset="UTF-8">
     <!-- Latest compiled and minified CSS -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

     <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     <!-- jQuery library -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <!-- Latest compiled JavaScript -->
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <!-- Font Awesome -->
     <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

     <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



     <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <!------ Include the above in your HEAD tag ---------->

     <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

 </head>

<body>


<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="pop1" role="tabpanel" aria-labelledby="pop1-tab">
        <div class="pt-4"></div>
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <div class="card-group">
                                   <?php

                                    $result_UltCod = "SELECT cod_anuncio FROM anuncio ORDER BY cod_anuncio DESC LIMIT 1;";
                                    $resultado_UltCod = mysqli_query($conn, $result_UltCod);
                                    $row_UltCod = mysqli_fetch_assoc($resultado_UltCod);


                                    for ($i = 1; $i <=  $row_UltCod['cod_anuncio']; $i++) {

                                        $result_usu = "SELECT nome,imagem_user FROM user WHERE cod_user = '$i';";
                                        $resultado_usu = mysqli_query($conn, $result_usu);
                                        $row_usu = mysqli_fetch_assoc($resultado_usu);

                                        $result_ANUN = "SELECT titulo,cod_anuncio,imagem FROM anuncio WHERE cod_anuncio = '$i';";
                                        $resultado_ANUN = mysqli_query($conn, $result_ANUN);
                                        $row_ANUN = mysqli_fetch_assoc($resultado_ANUN);


                                        $result_anun = "SELECT titulo,cod_anuncio,imagem FROM anuncio WHERE cod_anuncio = '$i';";
                                        $resultado_anun = mysqli_query($conn, $result_anun);
                                        $row_anun = mysqli_fetch_assoc($resultado_anun);



    echo '<div class="modal fade product_view" id="product_view">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <a href="#" data-dismiss="modal" class="class pull-right"><span class="glyphicon glyphicon-remove"></span></a>
                <h3 class="modal-title">';echo $row_anun['titulo'] . '</h3>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 product_img">
                        <img src="';echo $row_anun['imagem'] . ' " class="img-responsive">
                    </div>
                    <div class="col-md-6 product_content">
                        <h4>Criador: <span>';echo $row_usu['nome'] . ' <img src="';echo $row_usu['imagem_user'] . ' " name="aboutme" width="50" class="img-circle imgUser img-responsive" id="fotoperfil" style="float: right; margin-top: -5px;"></span></h4>
                        <label></label>
                        <h5 style="color: black;">Código: <span>';echo $row_anun['cod_anuncio'] . '</span></h4>
                        <h5 style="color: black;">Local <span>';echo $row_anun['cidade_anuncio'] . $row_anun['estado_anuncio'] .'</span></h4>
                        <h5 style="color: black;">Publicado em: <span>';echo $row_anun['dt_publicacao'] . '</span></h4>
                        <h5 style="color: black;">Categoria: <span>';echo $row_anun['categoria'] . '</span></h4>   
                         
                        <p>';echo $row_anun['descricao_anuncio'] . '</p>

                        <h3 class="cost">Orçamento Médio: <span>R$</span> ';echo $row_anun['pagamento'] . ' </h3>

                        <label></label>

                        <div class="space-ten"></div>
                        <div class="btn-ground">
                            <button type="button" class="btn btn-primary"><span class=" glyphicon glyphicon-comment"></span> Realizar Serviço</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>';



                                        echo '<section style="float: right;">
                                        <div class="card">
                                        <img class="card-img-top" alt="Card image cap" src="';
                                        echo $row_ANUN['imagem'] . '">
                                        <div class="card-body">
                                            <h4 class="card-title">';
                                        echo $row_ANUN['titulo'] . '</h4>
                                            <p class="card-text">Lance Médio em R$30</p>
                                        </div>
                                        <div class="card-footer">
                                             <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#product_view">Saiba Mais</button>
                                        </div>
                                        </div>
                                        </section>';
                                    }
                                   ?>


</body>
</html>
