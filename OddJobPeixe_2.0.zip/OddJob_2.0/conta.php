    <?php
    session_start();

    include("home.php");
    $situacao=$_GET['situacao'];
?>

  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  <!------ Include the above in your HEAD tag ---------->

  <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>

<body>

<div class="container">
    <div class="row">
        <div class="col-md-offset-2 col-md-8 col-lg-offset-3 col-lg-6">
         <div class="well profile">
            <div class="col-sm-12">
                <div class="col-xs-12 col-sm-8">
                    <h2><?php echo $_SESSION['nome'] . " " . $_SESSION['sobrenome']; ?></h2>
                    <p><strong>Cidade: </strong> <?php echo $_SESSION['cidade']."/".$_SESSION['estado'].".";?> </p>
                    <p><strong>Telefone: </strong> <?php echo $_SESSION['tel'];?> </p>
                    <p><strong>Formação: </strong> <?php echo $_SESSION['formacao'];?> </p>
                    <p><strong>Áreas: </strong>
                        <span class="tags">Mecânica/Hidráulica</span> 
                        <span class="tags">Sistemas de Encanamento</span>
                        <span class="tags">Marcenaria</span>
                        <span class="tags">Organização de Funerais</span>
                    </p>
                </div>
                 <div class="col-xs-12 col-sm-4 text-center">
                    <figure>
                        <img src="brabo.png" alt="" class="img-circle imgUser img-responsive">
                    </figure>
                </div>
            </div>            
            <div class="col-xs-12 divider text-center">
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong>245</strong></h2>                    
                    <p><small>Serviços Prestados</small></p>
                   <a href="enviaFoto.php"> <button class="btn btn-success btn-block"><span class="fa fa-user"></span> Foto do Perfil</button></a>
                </div>
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong>20</strong></h2>                    
                    <p><small>Serviços Cancelados</small></p>
                    <button class="btn btn-primary btn-block" id="myBtn"><span class="fa fa-user"></span> Ver Descrição </button>

                     </div>
                <div class="col-xs-12 col-sm-4 emphasis">
                    <h2><strong>43%</strong></h2>                    
                    <p><small>Aprovação</small></p>
                    <div class="btn-group dropup btn-block">
                    <a href="contaEdit.php">   <button type="button" class="btn btn-danger btn-block"><span class="fa fa-gear"></span> Editar</button></a>
                      </ul>
                    </div>
                </div>
            </div>
         </div>                 
        </div>
    </div>
</div>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog" style="margin-left: -500px; margin-top: 50px;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
           <center>
                    <img src="brabo.png" name="aboutme" width="100" class="img-circle imgUser img-responsive" id="fotoperfil"></a>
                    <h3 class="media-heading"><?php echo $_SESSION['nome'] . " " . $_SESSION['sobrenome']; ?><small> <?php echo " ".$_SESSION['estado'].".";?></small></h3>
                    <span><strong>Áreas: </strong></span>
                        <span class="label label-warning">Mecânica/Hidráulica</span>
                        <span class="label label-info">Sistemas de Encanamento</span>
                        <span class="label label-info">Marcenaria</span>
                        <span class="label label-success">Organização de Funerais</span>
                    </center>
                    <hr>
                    <center>
                    <p class="text-left"><strong>Formação Completa: </strong><br>
                        <?php echo $_SESSION['desc_user'];?></p>
                    <br>
                    </center>
                </div>
                <div class="modal-footer">
                    <center>
                    <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Fechar </button>
                    </center>
                </div>
      

</body>
</html>