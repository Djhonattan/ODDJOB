<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>OddJob</title>
	 <meta charset="UTF-8">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

		

</head>
<body class="bode">
	<section  class="folder">
		</section>
	<section class="pexe">
		<section class="jeh">
			<a href="index.php" class="xat">Home</a>
			
			<?php
            if ($_SESSION['logado']== false) {
                echo "<a href='loginReal.php' class=\"xat\">Entrar</a>";
            }
            ?>
	
			 <?php
            if ($_SESSION['logado']== true) {
                echo "<a href='conta.php' class=\"xat\">Minha Conta</a>";
            }
            ?>
            <?php
            if ($_SESSION['logado']== true) {
                echo "<a href='sair.php' class=\"xat\">Sair</a>";
            }
            
            
            ?>

            <section class="rat"><a style="font-size: 18px!important;" href="editarAnuncio.php" name="btnLogin" class="btn btn-warning" value="Anunciar">Anunciar</a></section>	 

    </section>
		<section class="ah">
		<<img src="hm.png" class="logo"> </section>


</section>
</body>
</html>