<?php
session_start();
include("home.php");
include_once("conexao.php");
$situacao=$_GET['situacao'];
?>

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

</head>

<body>


<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="pop1" role="tabpanel" aria-labelledby="pop1-tab">
        <div class="pt-4"></div>
        <div class="container">
            <div class="row">
                <div class="text-center">
                    <div class="card-group">
                                   <?php

                                    $result_UltCod = "SELECT cod_anuncio FROM anuncio ORDER BY cod_anuncio DESC LIMIT 1;";
                                    $resultado_UltCod = mysqli_query($conn, $result_UltCod);
                                    $row_UltCod = mysqli_fetch_assoc($resultado_UltCod);


                                    for ($i = 1; $i <=  $row_UltCod['cod_anuncio']; $i++) {

                                        $result_titulo = "SELECT titulo FROM anuncio WHERE cod_anuncio = '$i';";
                                        $resultado_Titu = mysqli_query($conn, $result_titulo);
                                        $row_Titu = mysqli_fetch_assoc($resultado_Titu);
                                        $result_imagem = "SELECT imagem FROM anuncio WHERE cod_anuncio = '$i';";
                                        $resultado_IMG = mysqli_query($conn, $result_imagem);
                                        $row_IMG = mysqli_fetch_assoc($resultado_IMG);


                                        echo '<section style="float: right;"><div class="card">
                                        <img class="card-img-top" alt="Card image cap" src="';
                                        echo $row_IMG['imagem'] . '">
                                        <div class="card-body">
                                            <h4 class="card-title">';
                                        echo $row_Titu['titulo'] . '</h4>
                                            <p class="card-text">Lance Médio em R$30</p>
                                        </div>
                                        <div class="card-footer">
                                            <button type="button" class="btn btn-danger btn-block">Saiba Mais</button>
                                        </div></section>';
                                    }
                                   ?>


</body>
</html>
