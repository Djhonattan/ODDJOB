<?php
	include("home.php");
?>
 <link rel="stylesheet" type="text/css" href="home.css">

    <head>
    <meta charset="utf-8">
    <title>Cadastro</title>
    <head>


<center><section class="fuca3">
	<section class="wasd">

        <form method="POST" action="salva_mensagem.php">
							<h3 class="tiete">Cadastro</h3>

									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="text" class="form-control" placeholder="Nome" name="nome" required >
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="text" class="form-control" placeholder="Sobrenome" name="sobrenome" required>
									</div>
								</div>
								<label for="exampleFormControlSelect1">Sexo</label>
								<div class="form-group">
    				
    				<label></label>
								<select class="saas" id="exampleFormControlSelect1" name="sexo">
   							  <option>Masculino</option>
						      <option>Feminino</option>
						    </select>
						  </div>
								<div class="col-md-12">
									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="email" class="form-control" placeholder="Email" name="email" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label></label>
                                        <input style="font-size: 15px!important;" type="password" class="form-control" placeholder="Senha" name="pwo" required>
									</div>
								</div>
								
								<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="text"  class="form-control" placeholder="Cidade" name="cidade" required>
									</div>
								</div>


								<div class="col-md-12">
									<div class="form-group">
										<label></label>
										<input style="font-size: 15px!important;" type="tel" class="form-control" placeholder="Telefone" name="tel" <?php //pattern="[0-9]{2}[9]{1}[0-9]{4}[0-9]{4}"?> required>
										<label></label>

									<div class="form-group">
    				<label for="exampleFormControlSelect1">Sigla do Estado:</label>
    				<label></label>
								<select class="saas" id="exampleFormControlSelect1" name="estado">
   							  <option>AC</option>
						      <option>AL</option>
						      <option>AP</option>
						      <option>AM</option>
						      <option>BA</option>
						      <option>CE</option>
						      <option>DF</option>
						      <option>ES</option>
						      <option>GO</option>
						      <option>MA</option>
						      <option>MT</option>
						      <option>MS</option>
						      <option>MG</option>
						      <option>PA</option>
						      <option>PB</option>
						      <option>PR</option>
						      <option>PE</option>
						      <option>PI</option>
						      <option>RJ</option>
						      <option>RN</option>
						      <option>RS</option>
						      <option>RO</option>
						      <option>RR</option>
						      <option>SC</option>
						      <option>SP</option>
						      <option>SE</option>
						    </select>
						  </div>
															


									</div>
								</div>
								<div class="col-md-12">
								</div>
								<div class="col-md-12">
									<div class="form-group">

									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<center><input style="font-size: 18px!important; width: 100px!important; margin-top: 5px!important;" type="submit" class="btn btn-outline-primary" value="Cadastrar"></center> 

									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
        </form>
		</section>
</section></center>
