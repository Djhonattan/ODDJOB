    <?php
    session_start();
    include("funcEdit.php");
    include("home.php");
    include("valida.php");

    $areas = explode(",", $_SESSION['areas_user']);

    $situacao=$_GET['situacao'];
?>

  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  <!------ Include the above in your HEAD tag ---------->

  <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

<div class="container" >
    <div class="row">
        <div class="col-md-offset-2 col-md-8 col-lg-offset-3 col-lg-6">
         <div class="well profile" style="margin-left: -350px !important;">
            <div class="col-sm-12">
                <div class="col-xs-12 col-sm-8">


<hr>
     <form class="form" action="editaPerfil.php" enctype="multipart/form-data" method="post" id="registrationForm">

<div class="container bootstrap snippet">
    <div class="row">
      <div class="col-sm-3"><!--left col-->

      <div class="text-center">
        <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail" alt="avatar">
        <h6>envie uma imagem diferente...</h6>
        <input type="file"  name="arquivo" class="text-center center-block file-upload">
      </div></hr><br>



          <ul class="list-group">
            <li class="list-group-item text-muted">Atividade <i class="fa fa-dashboard fa-1x"></i></li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Serviços Prestados</strong></span> 245</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Serviços Cancelados</strong></span> 20</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Aprovação</strong></span> 43%</li>
          </ul>

          <div class="panel panel-default">
            <div class="panel-heading">Redes Sociais</div>
            <div class="panel-body">
              <i class="fa fa-facebook fa-2x"></i> <i class="fa fa-github fa-2x"></i> <i class="fa fa-twitter fa-2x"></i> <i class="fa fa-pinterest fa-2x"></i> <i class="fa fa-google-plus fa-2x"></i>
            </div>
          </div>

        </div><!--/col-3-->
      <div class="col-sm-9">
            <ul class="nav nav-tabs">
              </ul>


          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                      <div class="form-group">
                          <div class="separa" style="margin-left: 50px";>
                          <div class="col-xs-6">
                              <label for="first_name"><h4>Nome</h4></label>
                              <input type="text" value="<?php echo $_SESSION['nome']; ?>" class="form-control" name="nome">
                          </div>

                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="last_name"><h4>Sobrenome</h4></label>
                              <input type="text" value="<?php $chamaSobrenome = inp_sobrenome($_SESSION['sobrenome']); ?>" class="form-control" name="sobrenome">
                          </div>
                      </div>

                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="phone"><h4>Telefone</h4></label>
                              <input type="tel" value="<?php $chamaTel = inp_tel($_SESSION['tel']); ?>" class="form-control" name="tel">
                          </div>
                      </div>

                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="email"><h4>E-mail</h4></label>
                              <input type="email" value="<?php $chamaEmail = inp_email($_SESSION['email']); ?>" class="form-control" name="email">
                          </div>
                      </div>
                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="password"><h4>Senha</h4></label>
                              <input type="text" value="<?php $chamaPwo = inp_pwo($_SESSION['pwo']); ?>" class="form-control" name="pwo">
                          </div>
                      </div>
                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Cidade</h4></label>
                              <input type="text" value="<?php $chamaCidade = inp_cidade($_SESSION['cidade']); ?>" class="form-control" name="cidade">
                          </div>
                      </div>
                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Sigla do Estado</h4></label>
            <label></label>
                <select class="form-control" name="estado" style="height: 35px;">
                  <option>AC</option>
                  <option>AL</option>
                  <option>AP</option>
                  <option>AM</option>
                  <option>BA</option>
                  <option>CE</option>
                  <option>DF</option>
                  <option>ES</option>
                  <option>GO</option>
                  <option>MA</option>
                  <option>MT</option>
                  <option>MS</option>
                  <option>MG</option>
                  <option>PA</option>
                  <option>PB</option>
                  <option>PR</option>
                  <option>PE</option>
                  <option>PI</option>
                  <option>RJ</option>
                  <option>RN</option>
                  <option>RS</option>
                  <option>RO</option>
                  <option>RR</option>
                  <option>SC</option>
                  <option>SP</option>
                  <option>SE</option>
                </select>
                          </div>
                      </div>
                      <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Formação</h4></label>
                              <input type="text" value="<?php $chamaFormacao = inp_formacao($_SESSION['formacao']); ?>" class="form-control"  name="formacao">
                          </div>
                      </div>

                    <div class="form-group">

                          <div class="col-xs-6">
                            <label for="password2"><h4>Áreas</h4></label>
                              <input type="text" value="<?php echo $areas[0] ?>" class="form-control"  name="area1">
                              <label></label>
                              <input type="text" value="<?php echo $areas[1] ?>" class="form-control"  name="area2">
                              <label></label>
                              <input type="text" value="<?php echo $areas[2] ?>" class="form-control"  name="area3">
                              <label></label>
                              <input type="text" value="<?php echo $areas[3] ?>" class="form-control"  name="area4">
                          </div>
                      </div>
                      <div class="form-group" >
                          <div class="col-xs-6">
                          	<section style="margin-top: -150px">
                            <label for="password2"><h4>Descrição/Formação Completa</h4></label>
                              <textarea id="desc_user" value="<?php $chamaDesc = inp_desc($_SESSION['desc_user'])?>" class="form-control" cols="30" rows="7"></textarea> 
                            
                          </section>

                          </div>
                          </div>
                           </div>
                      </div>
                           <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Salvar</button>
                                <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Resetar</button>
                            </div>
                      </div>
              </div><!--/tab-pane-->
          </div><!--/tab-content-->



</body>
</html>