<?php
	include_once('conexao.php');
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $pwo = $_POST['pwo'];
    $tel = $_POST['tel'];
    $sexo = $_POST['sexo'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
	
	$result_usario = "INSERT INTO user (nome, sobrenome, email, pwo, tel, sexo, cidade_user, estado_user) VALUES ('$nome', '$sobrenome', '$email', '$pwo', '$tel', '$sexo', '$cidade', '$estado');";
	$resultado_usuario= mysqli_query($conn, $result_usario);

	header("Location: loginReal.php");
?>