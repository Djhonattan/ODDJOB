<!DOCTYPE html>
<html>
<head>
	<title> Calculadora IP </title>
	 <link rel="stylesheet" type="text/css" href="estilo.css">
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">  
		<div class="fundo">
			<cneter><img id="logo" src="logo_calculadora.png"></center>
		</div>
	</nav>
</head>
<body>

	<div>
		<form class="fundinho">
					<center><h3>Calculadora IP</h3></center>
					<br>
						
					<h4>Insira o IP</h4>
							<input type="text" class="ip" placeholder="Ex: 192.168.0.1">
					<h4 >Selecione a Máscara</h4>			
			<select class="mask">
				<option value="/24">/24</option>
				<option value="/25">/25</option>
				<option value="/26">/26</option>
				<option value="/27">/27</option>
				<option value="/28">/28</option>
				<option value="/29">/29</option>
				<option value="/30">/30</option>
				<option value="/31">/31</option>
				<option value="/32">/32</option>
			</select>
			
			<br><br><br>
			<center><button class="ui inverted black button">Calcular!</button></center>
		</form>
	</body>
</html>

		    </div>
		</div>


</body>
</html>

