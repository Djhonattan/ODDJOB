<!DOCTYPE html>
<html>
	<head>
		<title>Caluladora IP</title>
	</head>
	<body style=" background-color: #CD5555;">
		<form style="margin-left: 41%; margin-top: 14%; padding: 2%; margin-right: 41%; border: dotted; border-radius: 20px; background-color: #FFA500; font-family: FreeMono, monospace;">
			<h1>Calculadora IP</h1>
			<h3>Insira o IP</h3>
			<input type="text" name="IP" pattern="[0-9].[0-9].[0-9].[0-9]" required>
			<br><br><br>
			<h3>Selecione a Máscara</h3>
			<select name=Máscara>
				<option value="/24">/24</option>
				<option value="/25">/25</option>
				<option value="/26">/26</option>
				<option value="/27">/27</option>
				<option value="/28">/28</option>
				<option value="/29">/29</option>
				<option value="/30">/30</option>
				<option value="/31">/31</option>
				<option value="/32">/32</option>
			</select>
			<br><br><br>
			<input type="submit" value="Calcular" style="border-radius: 5px; padding: 4%; color: #CD5555;">
		</form>
	</body>
</html>