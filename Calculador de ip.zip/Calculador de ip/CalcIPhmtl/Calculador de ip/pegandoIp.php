<?php

	$Ipi = $_POST[Ip];
	$Mask = $_POST[Mascara];
	$Jaaj = "soos";
	echo($Ipi ." Mascara:  \n" . $Mask );

