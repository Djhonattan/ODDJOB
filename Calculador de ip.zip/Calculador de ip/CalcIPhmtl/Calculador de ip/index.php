<!DOCTYPE html>
<html>
<head>
	<title> Calculadora IP </title>
	 <link rel="stylesheet" type="text/css" href="estilo.css">
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">  
		<div class="fundo">
			<cneter><img id="logo" src="logo_calculadora.png"></center>
		</div>
	</nav>
</head>
<body>

	<div>
		<form class="fundinho" method="post" action="pegandoIp.php">
					<center><h2>Calculadora IP:</h2></center>
					<br>
						
					<h3>Insira o IP</h3>
							<input name="Ip" type="text" class="ip" placeholder="Ex: 192.168.0.1">
							<br>
					<h3 >Selecione a Máscara:</h3>
					<select name = Mascara>
				<option value="/24">/24</option>
				<option value="/25">/25</option>
				<option value="/26">/26</option>
				<option value="/27">/27</option>
				<option value="/28">/28</option>
				<option value="/29">/29</option>
				<option value="/30">/30</option>
				<option value="/31">/31</option>
				<option value="/32">/32</option>
			</select>

		<br><br><br>
			<center><button class="ui inverted black button">Calcular!</button></center>
		</form>
<table class="ui very basic table" style="padding: 5%;">
  <thead>
    <tr>
      <th>Name</th>
      <th>Status</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>John</td>
      <td>Approved</td>
      <td>None</td>
    </tr>
    <tr>
      <td>Jamie</td>
      <td>Approved</td>
      <td>Requires call</td>
    </tr>
  </tbody>
</table>
	
	</body>
</html>

