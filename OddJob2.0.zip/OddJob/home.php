<!DOCTYPE html>
<html>
<head>
	<title>OddJob</title>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

		

</head>
<body class="bode">
	<section  class="folder">
		</section>
	<section class="pexe">
		<section class="jeh">
			<a href="chat.php" class="xat">Chat</a>
			<a href="chat.php" class="xat">Anuncios</a> 
			 <a href="loginReal.php" class="xat">Entrar</a>
			 <?php
            if ($_SESSION['logado']== true) {
                echo "<a href='conta.php' class=\"xat\">Minha Conta</a>";
            }
            ?>
            <?php
            if ($_SESSION['logado']== true) {
                echo "<a href='sair.php' class=\"xat\">Sair</a>";
            }
            ?>
    </section>
		<section class="ah">
		<a href="indexo.php"><img src="hm.png" class="logo"> </section></a>


</section>
</body>
</html>