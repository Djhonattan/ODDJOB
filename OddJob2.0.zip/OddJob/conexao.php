<?php
	$servidor = "localhost";
	$usuario = "aluno";
	$senha = "aluno";
	$dbname = "bd_oddjob";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>