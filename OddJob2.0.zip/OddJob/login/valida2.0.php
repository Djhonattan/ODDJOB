<?php

session_start();
include_once("conexao.php");
$btnLogin = filter_input(INPUT_POST, 'btnLogin', FILTER_SANITIZE_STRING);
if ($btnLogin) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
    $pwo = filter_input(INPUT_POST, 'pwo', FILTER_SANITIZE_STRING);
}
    //echo "$email - $pwo";

if((!empty($email)) AND (!empty($pwo))){
    //Pesquisar o usuário no BD
    $result_email = "SELECT cod_user, nome, sobrenome, email, pwo, tel, sexo FROM user WHERE email = '$email' LIMIT 1";
    $resultado_email = mysqli_query($conn, $result_email);
    if($resultado_email) {
        $row_email = mysqli_fetch_assoc($resultado_email);
        if (password_verify($pwo, $row_email['pwo'])) {
            $_SESSION['cod_user'] = $row_email['cod_user'];
            $_SESSION['nome'] = $row_email['nome'];
            $_SESSION['email'] = $row_email['email'];
            header("Location: administrativo.php");
        } else {
            $_SESSION['msg'] = "Login ou senha incorreto!";
            header("Location: loginReal.php");
        }
    }
}