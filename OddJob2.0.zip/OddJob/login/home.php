 <?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>OddJob</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">



</head>
<body class="bode">
	<section  class="folder">
		</section>
	<section class="pexe">
		<section class="jeh">
			<a href="chat.php" class="xat">Chat</a>
			<a href="chat.php" class="xat">Anuncios</a> 
			 <a href="login.php" class="xat">Entrar</a>
			 <a href="chat.php" class="xat">minha Conta</a>
			 </section

		<section class="ah">
		<a href="home.php"><img src="hm.png" class="logo"> </section></a>

				

</body>
</html>