<?php
    session_start();
	include("home.php");
?>
 <link rel="stylesheet" type="text/css" href="home.css">
<center><section class="fuca3">
	<section class="wasd">



							<h3 class="tiete">Login</h3>

        <form method="POST" action="valida2.0.php">
									<div class="form-group">
										<label></label>
										<input type="email" class="form-control" placeholder="E-mail" name="email" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label></label>
										<input type="password" class="form-control" placeholder="Senha" name="pwo" required>
									</div>
								</div>
								<center> <h6>Não tem uma conta? Crie <a href="formUsuario.php">Aki</a></h6></center>
                                <center><input type="submit" name="btnLogin" class="btn btn-outline-primary" value="Logar"></center>
        </form>

        <?php
        if(isset($_SESSION['msg'])){
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
        ?>
    </section>