<?php
session_start();
    include_once('conexao.php');
    include('valida.php');

    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $pwo = $_POST['pwo'];
    $tel = $_POST['tel'];
    $sexo = $_POST['sexo'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $desc_user = $_POST['desc_user'];
    $formacao = $_POST['formacao'];

    $areas_user = $_POST['area1']. "," .$_POST['area2']. "," .$_POST['area3']. "," .$_POST['area4'];

    $codUser = $_SESSION['cod_user'];

    $result_edit = "UPDATE user SET nome = '$nome', sobrenome = '$sobrenome', 
    email = '$email', pwo = '$pwo', tel = '$tel', sexo = '$sexo', cidade_user = '$cidade', 
    estado_user = '$estado', desc_user = '$desc_user', areas_user = '$areas_user', 
    formacao = '$formacao'  WHERE cod_user = '$codUser'";
    $resultado_edit= mysqli_query($conn, $result_edit);

    header("Location: validaEdit.php");
?>